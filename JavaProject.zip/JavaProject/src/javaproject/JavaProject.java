/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaproject;

/**
 *
 * @author one
 */
public class JavaProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Login log =new Login();
        log.show();
    }
}
